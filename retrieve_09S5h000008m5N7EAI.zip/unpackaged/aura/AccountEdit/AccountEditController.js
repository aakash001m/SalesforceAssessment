({
	myAction : function(component, event, helper) {
		
	}
    /*handleOnLoad : function(component, event, helper) {
    
    
}
    handleOnSubmit : function(component, event, helper) {
    
    
}
    handleOnSuccess : function(component, event, helper) {
    
    
}
    handleOnError : function(component, event, helper) {
    
    
}
    handleOnCancel : function(component, event, helper) 
{
    var recId=component.get("v.recordId");
    var navEvt=$A.get("e.force:navigateToSObject");
    navEvt.SetParams({
        "recordId":recId;
        
    })
    navEvt.fire();
    
        
    
    
}*/
})