import { LightningElement } from 'lwc';
export default class Testaccount extends LightningElement {

}