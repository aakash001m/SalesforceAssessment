import { LightningElement } from 'lwc';
export default class UnitTest extends LightningElement {

}