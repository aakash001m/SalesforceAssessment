import { LightningElement } from 'lwc';
export default class AccountCreator extends LightningElement {

}